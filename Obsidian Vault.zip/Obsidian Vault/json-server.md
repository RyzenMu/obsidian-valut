1. inside package.json create npm script as follows
2. "server" : "json-server --watch data/question.json --port 8000"
3. syntax "server" : "json-server --watch folder-name/file-name --port port-number"
4. npm run server
5. 