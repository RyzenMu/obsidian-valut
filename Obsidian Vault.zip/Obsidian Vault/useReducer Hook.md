1. another powerful way of managing state
2. important to understand [[Redux]]
3. Half the section is practicing another project
4. useReducer hook is most advanced state of handling states.
5. It always works with a reducer function.
6. The reducer function always take in previous state and action as parameters.
7. Always create reducer function outside the component.
8. The reducer function get called when dispatch is called
9. dispatch = action
10. give an object in dispatch,  with propery type and payload, do not use fixed numbers.
11. payload is optional in simple reducer functions.
12.  useReducer is mostly used to update state which is an complex object and not a single value.
13. The main use case of useReducer is when a component has lot of state variables and state updates.
14. when multiple event handlers use useReducer.
15. when multiple state updates needs to happen at same time use useReducer (as a reaction when starting a game)
16. set score 0, start game, set timer 0
17. when updating one piece of state depends on multiple other pieces of state.
18. syntax const [state, dispatch] = useReducer(reducer, initialState).
19. stores related pieces of state in state object
20. useReducer needs reducer:function containing all logic to update state. Decouples state logic from component.
21. we can move event handler logic inside reducer function.
22. reducer function is similar to setState in steroids
23. reducer: pure function (no side effects!) that takes current state and action, and returns the next state.
24. state is immuatable in react
25. reducer is not allowed to mutate the state.
26. action: object that describes how to update state.
27. action usually has {type and payload}
28. dispatch: function to trigger state updates, by sending actions from event handlers to the reducer.
29. dispatch === setState()
30.  npm i [[json-server]] is a small server for small projects
 

| useState                                                                                                                  | useReducer                                                                  |
| ------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| ideal for single and individual pieces of state                                                                           | ideal for multiple related pieces of state and complex state                |
| logic to update the state is directly placed in event handlers or effects, spread all overr single or multiple components | logic to update state lives in one central place, decoupled from components |
| state is updated by calling setState (setter returned from useState)                                                      | state is updated by dispatching an action to a reducer                      |
| Imperative state updates                                                                                                  | Declarative state updates : complex state transitions are mapped to actions |
| Easy to understand and use                                                                                                | More difficult to understand and implement                                  |

![[Pasted image 20250112071935.png]]