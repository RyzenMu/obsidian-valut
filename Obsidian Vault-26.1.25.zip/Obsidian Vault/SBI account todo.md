1. Refresh Yono app
2. Reset Online Login and Transaction password
3. Apply for new ATM card.