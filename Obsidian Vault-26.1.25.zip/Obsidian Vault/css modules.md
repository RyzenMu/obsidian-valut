1. create file syntax is {componentname}.module.css
2. css modules do not allow elements
3. css modules allow classname and idname
```
4. import { NavLink} from "react-router-dom";  
import styles from './PageNav.module.css';  
  
function PageNav() {  
    return (  
<nav className={styles.nav}>  
    <ul>        <li><NavLink to='/'>Homepage</NavLink></li>  
        <li><NavLink to='/product'>Product</NavLink></li>  
        <li><NavLink to='/pricing'>Pricing</NavLink></li>  
    </ul></nav>);  
}  
  
export default PageNav;
```
5. global css can also be added to module css
6. :global(.test) { background-color: orangered}
7. use variableName like javaScript case
8. 