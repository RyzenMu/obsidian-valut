1. react router is used to build SPA.
2. react router is the most  important 3rd party library
3. building our first SPA
4. styles with css modules
5. for the first time we are going to use vite create
6. npm create vite@latest
7. index.html is outside src , while creating in vite
8. index.html is outside src because, this is the best structure
9. instead of index.js in vite we use main.jsx
10. Here the entry point is main.jsx instead of index.js
11. we have to manually set eslint in vite
12. we have to install several packages alonside eslint, vite-plugin-eslint, eslint-config-react-app --save-dev
13. npm install --legacy-peer-deps, if clash between versions 
14. create .eslintrc.json in src folder
```
15. {"extends":"react-app"}
```
16.vite.config.js --> {import eslint from 'vite-plugin-eslint'}
17. Add eslint() to plugins array
18. plugins: [react(), eslint()]
19. with routing , we match different URLs to different UI views (react components) : routes
20. This enables users to navigate between different application screens, using the browser URLs.
21. keeps the UI in sync with the current browser URL.
22. This type of routing only works on the client side.
23. most front-end frameworks have client-side routing baked inside
24. but react does not have routing on its own
25. react uses 3rd party pakages for different functionalities like routing.
26. reactRouter is the most important 3rd party package.
27. routing allows us to build [[single-page-applications (SPA)]]
28. npm install react-router-dom@6
29. 
```
function App() {  
    return (  
        <BrowserRouter>  
            <Routes>                <Route path='product' element={<Product/>} />  
		            </Routes>        </BrowserRouter>    );
```
30. path='*' is used for Page not Found Element/Component
31. [[Link]] and NavLink element is provided by React-Router for links to click
32. The NavLink provides us with the classname as 'active', which we can use for styling
33. 