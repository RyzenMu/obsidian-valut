1. Application that is executed entirely on the client (browsers).
2. Routes: different URLs correspond to different views (components).
3. user clicks the router link.
4. URL changing is done by [[React Router]] 
5. then DOM is updated by javascript (React) therefore the page.
6. in normal webpages if we click a link, a new page is created from scratch.
7. but in SPA the page is never reloaded but updated by javascript(React).
8. This feels like native desktop or mobile application.
9. Whenever a new route happens, React component corresponding to the new URL is rendered.
10. Server can serve data (Load data from web API).
11. Additional data might be loaded from a web API.
12. SPA are never reloaded.
13. 