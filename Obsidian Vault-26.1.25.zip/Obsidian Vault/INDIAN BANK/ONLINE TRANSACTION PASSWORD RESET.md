1. login with your regular password.
2.  Go to reset transaction password section 
3. generate code
4. send email with that code number to Ennore Indian bank email or sent by post.
5. Follow up to reset Indian bank reset the indian bank transaction password.
6. 