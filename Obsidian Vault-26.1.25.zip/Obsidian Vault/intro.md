1. [[Advanced state management]]
2. [[useReducer Hook]]
3. [[context API]]
4. [[Redux]]
5. [[Four different projects]]
6. [[vite]]
7. [[React Router]]
8. [[useMemo]]
9. [[useCallback]]
10. 

