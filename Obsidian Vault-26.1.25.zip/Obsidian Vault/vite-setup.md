5. for the first time we are going to use vite create
6. npm create vite@latest
7. index.html is outside src , while creating in vite
8. index.html is outside src because, this is the best structure
9. instead of index.js in vite we use main.jsx
10. Here the entry point is main.jsx instead of index.js
11. we have to manually set eslint in vite
12. we have to install several packages alonside eslint, vite-plugin-eslint, eslint-config-react-app --save-dev
13. npm install --legacy-peer-deps, if clash between versions 
14. create .eslintrc.json in src folder
```
15. {"extends":"react-app"}
```
16.vite.config.js --> {import eslint from 'vite-plugin-eslint'}
17. Add eslint() to plugins array
18. plugins: [react(), eslint()]
19. 
