```
1. <Link to='pricing'>Pricing</Link>

```
```
2. <NavLink to='pricing'>Pricing</NavLink>
```
3. NavLink will highlight the link.
4. 