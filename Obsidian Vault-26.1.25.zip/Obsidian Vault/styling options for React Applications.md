1. React is un-opiniated thus allowing all the frameworks.
2. React does not care about styling
3. There are many 3rd party libraries for styling
 

| Styling Option                        | Where                           | How                   | Scope                 | Based On              |
| ------------------------------------- | ------------------------------- | --------------------- | --------------------- | --------------------- |
| inline css                            | jsx elements                    | style prop            | JSx element           | css                   |
| external css file / sass              | External file                   | className prop        | entire app            | css                   |
| css modules                           | one external file per component | classname prop        | component             | css                   |
| css-in-js                             | external file or component file | creates new component | component             | javascript            |
| utility-first-css (Tailwind)          | jsx elements                    | classname prop        | jsx element           | css                   |
| UI libraries like MI, chakra, Mantine | pre-styled components           | pre-styled components | pre-styled components | pre-styled components |

